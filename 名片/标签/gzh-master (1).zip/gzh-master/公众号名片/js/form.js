	//手机第二栏
	$('.btn-uname').click(function(){
		$('.uname-none').stop().slideToggle()
	})